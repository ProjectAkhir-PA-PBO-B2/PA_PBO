package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import entitas.JobListing;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import entitas.Session;

public class Database {
    private static final String URL = "jdbc:mysql://localhost:3306/joblisting";
    private static final String USER = "root";
    private static final String PASSWORD = "";


    public static Connection getConnection() {
        try {
            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
            return con;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
    
        public List<JobListing> getJobListingsSortedBySalary(boolean ascending) {
    List<JobListing> jobListings = new ArrayList<>();
    String order = ascending ? "ASC" : "DESC";
    String query = "SELECT lp.ID_Lowongan, lp.Judul_Pekerjaan, p.Nama_Perusahaan, lp.Lokasi, lp.Gaji " +
                   "FROM lowongan_pekerjaan lp " +
                   "JOIN perusahaan p ON lp.PERUSAHAAN_ID_Perusahaan = p.ID_Perusahaan " +
                   "WHERE lp.ID_Lowongan NOT IN (" +
                   "    SELECT LOWONGAN_PEKERJAAN_ID_Lowongan " +
                   "    FROM lamaran " +
                   "    WHERE PELAMAR_KERJA_ID_Pelamar = ?" +
                   ") " +
                   "ORDER BY lp.Gaji " + order;

    try (Connection con = getConnection();
         PreparedStatement ps = con.prepareStatement(query)) {

        // Ambil ID Pelamar dari sesi
        String userId = Session.getInstance().getUserId();
        ps.setString(1, userId);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                JobListing job = new JobListing(
                    rs.getString("ID_Lowongan"),
                    rs.getString("Judul_Pekerjaan"),
                    rs.getString("Nama_Perusahaan"),
                    rs.getString("Lokasi"),
                    rs.getString("Gaji")
                );
                jobListings.add(job);
            }
        }
    } catch (SQLException e) {
        System.out.println("Error loading sorted job listings: " + e.getMessage());
    }
    return jobListings;
}
    
    public List<JobListing> getJobListings() {
    List<JobListing> jobListings = new ArrayList<>();
    String query = "SELECT lp.ID_Lowongan, lp.Judul_Pekerjaan, p.Nama_Perusahaan, lp.Lokasi, lp.Gaji " +
                   "FROM lowongan_pekerjaan lp " +
                   "JOIN perusahaan p ON lp.PERUSAHAAN_ID_Perusahaan = p.ID_Perusahaan " +
                   "WHERE lp.ID_Lowongan NOT IN (" +
                   "    SELECT LOWONGAN_PEKERJAAN_ID_Lowongan " +
                   "    FROM lamaran " +
                   "    WHERE PELAMAR_KERJA_ID_Pelamar = ?" +
                   ") " +
                   "ORDER BY lp.ID_lowongan ASC";

    try (Connection con = getConnection();
         PreparedStatement ps = con.prepareStatement(query)) {

        // Ambil ID Pelamar dari sesi
        String userId = Session.getInstance().getUserId();
        ps.setString(1, userId);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                JobListing job = new JobListing(
                    rs.getString("ID_Lowongan"),
                    rs.getString("Judul_Pekerjaan"),
                    rs.getString("Nama_Perusahaan"),
                    rs.getString("Lokasi"),
                    rs.getString("Gaji")
                );
                jobListings.add(job);
            }
        }
    } catch (SQLException e) {
        System.out.println("Error loading job listings: " + e.getMessage());
    }
    return jobListings;
}

    public List<JobListing> searchJobListings(String searchQuery) {
    List<JobListing> jobListings = new ArrayList<>();
    String query = "SELECT lp.ID_Lowongan, lp.Judul_Pekerjaan, p.Nama_Perusahaan, lp.Lokasi, lp.Gaji " +
                   "FROM lowongan_pekerjaan lp " +
                   "JOIN perusahaan p ON lp.PERUSAHAAN_ID_Perusahaan = p.ID_Perusahaan " +
                   "WHERE lp.ID_Lowongan NOT IN (" +
                   "    SELECT LOWONGAN_PEKERJAAN_ID_Lowongan " +
                   "    FROM lamaran " +
                   "    WHERE PELAMAR_KERJA_ID_Pelamar = ?" +
                   ") " +
                   "AND (lp.Judul_Pekerjaan LIKE ? OR lp.Lokasi LIKE ? OR p.Nama_Perusahaan LIKE ?)";

    try (Connection con = getConnection();
         PreparedStatement ps = con.prepareStatement(query)) {

        // Ambil ID Pelamar dari sesi
        String userId = Session.getInstance().getUserId();
        ps.setString(1, userId);

        // Wildcard pencarian
        String searchPattern = "%" + searchQuery + "%";
        ps.setString(2, searchPattern);
        ps.setString(3, searchPattern);
        ps.setString(4, searchPattern);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                JobListing job = new JobListing(
                    rs.getString("ID_Lowongan"),
                    rs.getString("Judul_Pekerjaan"),
                    rs.getString("Nama_Perusahaan"),
                    rs.getString("Lokasi"),
                    rs.getString("Gaji")
                );
                jobListings.add(job);
            }
        }
    } catch (SQLException e) {
        System.out.println("Error searching job listings: " + e.getMessage());
    }
    return jobListings;
}

}
