package entitas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Connection.Database;

public class PelamarKerja {
    private int idPelamar;
    private String namaPelamar;
    private String sandi;
    private String nomorTelepon;
    private String email;
    private String cv;

    public PelamarKerja(int idPelamar, String namaPelamar, String sandi, 
                        String nomorTelepon, String email, String cv) {
        this.idPelamar = idPelamar;
        this.namaPelamar = namaPelamar;
        this.sandi = sandi;
        this.nomorTelepon = nomorTelepon;
        this.email = email;
        this.cv = cv;
    }
    
     public PelamarKerja() {
    }
 public static PelamarKerja login(String nama, String password) {
        Connection con = Database.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        PelamarKerja pelamar = null;
        
        try {
            String query = "SELECT * FROM pelamar_kerja WHERE Nama_Pelamar = ? AND sandi = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, nama);
            ps.setString(2, password);
            rs = ps.executeQuery();

            if (rs.next()) {
                pelamar = new PelamarKerja();
                pelamar.setIdPelamar(rs.getInt("ID_Pelamar"));
                pelamar.setNamaPelamar(rs.getString("Nama_Pelamar"));
                pelamar.setSandi(rs.getString("sandi"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return pelamar;
    }


    public int getIdPelamar() {
        return idPelamar;
    }

    public void setIdPelamar(int idPelamar) {
        this.idPelamar = idPelamar;
    }

    public String getNamaPelamar() {
        return namaPelamar;
    }

    public void setNamaPelamar(String namaPelamar) {
        this.namaPelamar = namaPelamar;
    }

    public String getSandi() {
        return sandi;
    }

    public void setSandi(String sandi) {
        this.sandi = sandi;
    }

    public String getNomorTelepon() {
        return nomorTelepon;
    }

    public void setNomorTelepon(String nomorTelepon) {
        this.nomorTelepon = nomorTelepon;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCv() {
        return cv;
    }

    public void setCv(String cv) {
        this.cv = cv;
    }
}

