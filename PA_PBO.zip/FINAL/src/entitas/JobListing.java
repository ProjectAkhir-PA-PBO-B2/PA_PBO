package entitas;

public class JobListing {
    private String idLowongan;
    private String judulPekerjaan;
    private String namaPerusahaan;
    private String lokasi;
    private String gaji;

    public JobListing(String idLowongan, String judulPekerjaan, String namaPerusahaan, String lokasi, String gaji) {
        this.idLowongan = idLowongan;
        this.judulPekerjaan = judulPekerjaan;
        this.namaPerusahaan = namaPerusahaan;
        this.lokasi = lokasi;
        this.gaji = gaji;
    }

    public String getIdLowongan() {
        return idLowongan;
    }

    public String getJudulPekerjaan() {
        return judulPekerjaan;
    }

    public String getNamaPerusahaan() {
        return namaPerusahaan;
    }

    public String getLokasi() {
        return lokasi;
    }

    public String getGaji() {
        return gaji;
    }
}
