package entitas;

// Utility for session
public class Session {
    private static Session instance;
    private static String userId;
    private static String perusahaanId;

    // Private constructor to prevent instantiation
    private Session() {}

    // Singleton pattern to ensure only one instance exists
    public static Session getInstance() {
        if (instance == null) {
            instance = new Session();
        }
        return instance;
    }
    
    // Set user ID (for pelamar or user)
    public static void setUserId(String userId) {
        Session.userId = userId;
    }

    // Get user ID
    public static String getUserId() {
        return userId;
    }

    // Set perusahaan ID (for company users)
    public void setPerusahaanId(String perusahaanId) {
        Session.perusahaanId = perusahaanId;
    }

    // Get perusahaan ID
    public String getPerusahaanId() {
        return perusahaanId;
    }

    // Clear session
    public static void clearSession() {
        userId = null;
        perusahaanId = null;
    }
}
