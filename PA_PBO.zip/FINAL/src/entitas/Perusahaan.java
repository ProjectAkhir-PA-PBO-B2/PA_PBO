package entitas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Connection.Database;
import javax.swing.JOptionPane;

public class Perusahaan {
    private int idPerusahaan;
    private String namaPerusahaan;
    private String sandi;
    private String alamat;
    private String emailPerusahaan;
    private String website;
    private String nomorTelepon;

    public Perusahaan(int idPerusahaan, String namaPerusahaan, String sandi, 
                      String alamat, String emailPerusahaan, String website, 
                      String nomorTelepon) {
        this.idPerusahaan = idPerusahaan;
        this.namaPerusahaan = namaPerusahaan;
        this.sandi = sandi;
        this.alamat = alamat;
        this.emailPerusahaan = emailPerusahaan;
        this.website = website;
        this.nomorTelepon = nomorTelepon;
    }
    
    
    
     public Perusahaan() {
    }
     
         public Perusahaan(Integer idPerusahaan, String namaPerusahaan) {
        this.idPerusahaan = idPerusahaan;
        this.namaPerusahaan = namaPerusahaan;
    }

     public static Perusahaan login(String nama, String password) {
        Connection con = Database.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Perusahaan perusahaan = null;
        
        try {
            String query = "SELECT * FROM perusahaan WHERE Nama_Perusahaan = ? AND sandi = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, nama);
            ps.setString(2, password);
            rs = ps.executeQuery();

            if (rs.next()) {
                perusahaan = new Perusahaan();
                perusahaan.setIdPerusahaan(rs.getInt("ID_Perusahaan"));
                perusahaan.setNamaPerusahaan(rs.getString("Nama_Perusahaan"));
                perusahaan.setSandi(rs.getString("sandi"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return perusahaan;
    }

    private Perusahaan(String idPerusahaan, String namaPerusahaan, String alamat) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getIdPerusahaan() {
        return idPerusahaan;
    }

    public void setIdPerusahaan(int idPerusahaan) {
        this.idPerusahaan = idPerusahaan;
    }

    public String getNamaPerusahaan() {
        return namaPerusahaan;
    }

    public void setNamaPerusahaan(String namaPerusahaan) {
        this.namaPerusahaan = namaPerusahaan;
    }

    public String getSandi() {
        return sandi;
    }

    public void setSandi(String sandi) {
        this.sandi = sandi;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getEmailPerusahaan() {
        return emailPerusahaan;
    }

    public void setEmailPerusahaan(String emailPerusahaan) {
        this.emailPerusahaan = emailPerusahaan;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getNomorTelepon() {
        return nomorTelepon;
    }

    public void setNomorTelepon(String nomorTelepon) {
        this.nomorTelepon = nomorTelepon;
    }
    

        public static Perusahaan getPerusahaanByName(String companyName) {
        String query = "SELECT ID_Perusahaan, Nama_Perusahaan FROM perusahaan WHERE Nama_Perusahaan = ?";
        Perusahaan perusahaan = null;

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, companyName);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String idPerusahaan = rs.getString("ID_Perusahaan");
                    String namaPerusahaan = rs.getString("Nama_Perusahaan");
                   perusahaan = new Perusahaan(Integer.parseInt(idPerusahaan), namaPerusahaan);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving company: " + e.getMessage());
        }

        return perusahaan;
    }
        public static Perusahaan getPerusahaanDetails(String namaPerusahaan) {
    String query = "SELECT * FROM perusahaan WHERE Nama_Perusahaan = ?";
    Perusahaan perusahaan = null;

    try (Connection con = Database.getConnection();
         PreparedStatement ps = con.prepareStatement(query)) {
        ps.setString(1, namaPerusahaan);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String idPerusahaan = rs.getString("ID_Perusahaan");
                String alamat = rs.getString("Alamat");

                perusahaan = new Perusahaan(idPerusahaan, namaPerusahaan, alamat);
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error fetching company details: " + e.getMessage());
    }

    return perusahaan;



        }
        
}