/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entitas;
import java.util.Date;
import Connection.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class Lamaran {
    private String idLamaran;
    private String tanggalLamaran;
    private String statusLamaran;
    private String idPelamar;
    private String idLowongan;
    private LowonganPekerjaan lowonganPekerjaan;

    public Lamaran(String idLamaran, String idPelamar, String idLowongan) {
        this.idLamaran = idLamaran;
        this.tanggalLamaran = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        this.statusLamaran = "diproses"; 
        this.idPelamar = idPelamar;
        this.idLowongan = idLowongan;
    }

 
    public String getIdLamaran() {
        return idLamaran;
    }

    public void setIdLamaran(String idLamaran) {
        this.idLamaran = idLamaran;
    }

    public String getTanggalLamaran() {
        return tanggalLamaran;
    }

    public void setTanggalLamaran(String tanggalLamaran) {
        this.tanggalLamaran = tanggalLamaran;
    }

    public String getStatusLamaran() {
        return statusLamaran;
    }

    public void setStatusLamaran(String statusLamaran) {
        this.statusLamaran = statusLamaran;
    }

    public String getIdPelamar() {
        return idPelamar;
    }

    public void setIdPelamar(String idPelamar) {
        this.idPelamar = idPelamar;
    }

    public String getIdLowongan() {
        return idLowongan;
    }

    public void setIdLowongan(String idLowongan) {
        this.idLowongan = idLowongan;
    }
     public LowonganPekerjaan getLowonganPekerjaan() {
        return lowonganPekerjaan;
    }



    public boolean save() {
        Database db = new Database();
        Connection conn = db.getConnection();
        String query = "INSERT INTO lamaran (ID_Lamaran, Tanggal_Lamaran, Status_Lamaran, PELAMAR_KERJA_ID_Pelamar, LOWONGAN_PEKERJAAN_ID_Lowongan) " +
                       "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, this.idLamaran);
            ps.setString(2, this.tanggalLamaran);
            ps.setString(3, this.statusLamaran);
            ps.setString(4, this.idPelamar);
            ps.setString(5, this.idLowongan);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error while saving lamaran: " + e.getMessage());
            return false;
        }
    }


    public static String generateNextId() {
        String query = "SELECT MAX(ID_Lamaran) FROM lamaran";
        try (Connection conn = new Database().getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                int nextId = rs.getInt(1) + 1; 
                return String.valueOf(nextId);
            }
        } catch (SQLException e) {
            System.err.println("Error generating next ID: " + e.getMessage());
        }
        return null;
    }
     public static List<Lamaran> getLamaranByPelamar(String idPelamar) {
        List<Lamaran> lamaranList = new ArrayList<>();
        String query = "SELECT l.LOWONGAN_PEKERJAAN_ID_Lowongan, l.Status_Lamaran " +
                       "FROM lamaran l " +
                       "WHERE l.PELAMAR_KERJA_ID_Pelamar = ?";

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, idPelamar);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String idLowongan = rs.getString("LOWONGAN_PEKERJAAN_ID_Lowongan");
                    String statusLamaran = rs.getString("Status_Lamaran");

                    Lamaran lamaran = new Lamaran(idPelamar, idLowongan, statusLamaran);
                    lamaranList.add(lamaran);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving lamaran: " + e.getMessage());
        }
        return lamaranList;
    }
     public static String getNextLamaranId() {
        String query = "SELECT MAX(ID_Lamaran) FROM lamaran";
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                int nextId = rs.getInt(1) + 1; 
                return String.valueOf(nextId);
            }
        } catch (SQLException e) {
            System.err.println("Error generating next ID_Lamaran: " + e.getMessage());
        }
        return null;
    }
}
