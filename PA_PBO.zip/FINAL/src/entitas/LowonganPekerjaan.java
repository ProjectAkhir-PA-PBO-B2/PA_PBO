package entitas;
import Connection.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class LowonganPekerjaan {
    private String idLowongan;
    private String judulPekerjaan;
    private String namaPerusahaan;
    private String lokasi;
    private String gaji;
    private String deskripsiPekerjaan;
    private Perusahaan perusahaan;

  public LowonganPekerjaan(String idLowongan, String judulPekerjaan, String namaPerusahaan,
                             String lokasi, String gaji, String deskripsiPekerjaan) {
        this.idLowongan = idLowongan;
        this.judulPekerjaan = judulPekerjaan;
        this.namaPerusahaan = namaPerusahaan;
        this.lokasi = lokasi;
        this.gaji = gaji;
        this.deskripsiPekerjaan = deskripsiPekerjaan;
    }

   public LowonganPekerjaan() {
    }
   
     public LowonganPekerjaan(String idLowongan, String judulPekerjaan, String namaPerusahaan,
                             String lokasi, String gaji) {
        this.idLowongan = idLowongan;
        this.judulPekerjaan = judulPekerjaan;
        this.namaPerusahaan = namaPerusahaan;
        this.lokasi = lokasi;
        this.gaji = gaji;
    }

     public Perusahaan getPerusahaan() {
        if (perusahaan == null) {
            String query = "SELECT p.ID_Perusahaan, p.Nama_Perusahaan " +
                           "FROM perusahaan p " +
                           "JOIN lowongan_pekerjaan lp ON p.ID_Perusahaan = lp.PERUSAHAAN_ID_Perusahaan " +
                           "WHERE lp.ID_Lowongan = ?";
            try (Connection con = Database.getConnection();
                 PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, this.idLowongan); 
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        perusahaan = new Perusahaan();
                        perusahaan.setIdPerusahaan(rs.getInt("ID_Perusahaan"));
                        perusahaan.setNamaPerusahaan(rs.getString("Nama_Perusahaan"));
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace(); 
            }
        }
        return perusahaan;
    }
    
   
    public String getIdLowongan() {
        return idLowongan;
    }

    public void setIdLowongan(String idLowongan) {
        this.idLowongan = idLowongan;
    }

    public String getJudulPekerjaan() {
        return judulPekerjaan;
    }

    public void setJudulPekerjaan(String judulPekerjaan) {
        this.judulPekerjaan = judulPekerjaan;
    }

    public String getNamaPerusahaan() {
        return namaPerusahaan;
    }

    public void setNamaPerusahaan(String namaPerusahaan) {
        this.namaPerusahaan = namaPerusahaan;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getGaji() {
        return gaji;
    }

    public void setGaji(String gaji) {
        this.gaji = gaji;
    }

    public String getDeskripsiPekerjaan() {
        return deskripsiPekerjaan;
    }

    public void setDeskripsiPekerjaan(String deskripsiPekerjaan) {
        this.deskripsiPekerjaan = deskripsiPekerjaan;
    }

    public static LowonganPekerjaan getDetailPekerjaan(String idLowongan) {
        LowonganPekerjaan lowonganPekerjaan = null;
        String query = "SELECT lp.Judul_Pekerjaan, p.Nama_Perusahaan, lp.Lokasi, lp.Gaji, lp.Deskripsi_Pekerjaan " +
                       "FROM lowongan_pekerjaan lp " +
                       "JOIN perusahaan p ON lp.PERUSAHAAN_ID_Perusahaan = p.ID_Perusahaan " +
                       "WHERE lp.ID_Lowongan = ?";

        try (Connection conn = new Database().getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, idLowongan);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                lowonganPekerjaan = new LowonganPekerjaan(
                        idLowongan,
                        rs.getString("Judul_Pekerjaan"),
                        rs.getString("Nama_Perusahaan"),
                        rs.getString("Lokasi"),
                        rs.getString("Gaji"),
                        rs.getString("Deskripsi_Pekerjaan")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error while fetching job details: " + e.getMessage());
        }

        return lowonganPekerjaan;
    }
    
     public static List<LowonganPekerjaan> searchLowongan(String searchQuery) {
        List<LowonganPekerjaan> lowonganList = new ArrayList<>();
        String query = "SELECT lp.ID_Lowongan, lp.Judul_Pekerjaan, p.Nama_Perusahaan, lp.Lokasi, lp.Gaji " +
                       "FROM lowongan_pekerjaan lp " +
                       "JOIN perusahaan p ON lp.PERUSAHAAN_ID_Perusahaan = p.ID_Perusahaan " +
                       "WHERE lp.Judul_Pekerjaan LIKE ? OR lp.Lokasi LIKE ? OR p.Nama_Perusahaan LIKE ?";

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            String searchPattern = "%" + searchQuery + "%";
            ps.setString(1, searchPattern);
            ps.setString(2, searchPattern);
            ps.setString(3, searchPattern);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String idLowongan = rs.getString("ID_Lowongan");
                    String judulPekerjaan = rs.getString("Judul_Pekerjaan");
                    String namaPerusahaan = rs.getString("Nama_Perusahaan");
                    String lokasi = rs.getString("Lokasi");
                    String gaji = rs.getString("Gaji");

                    LowonganPekerjaan lowongan = new LowonganPekerjaan(idLowongan, judulPekerjaan, namaPerusahaan, lokasi, gaji);
                    lowonganList.add(lowongan);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error searching for lowongan: " + e.getMessage());
        }

        return lowonganList;
    }
     public static LowonganPekerjaan getLowonganDetails(String idLowongan) {
    String query = "SELECT * FROM lowongan_pekerjaan WHERE ID_Lowongan = ?";
    LowonganPekerjaan lowongan = null;

    try (Connection con = Database.getConnection();
         PreparedStatement ps = con.prepareStatement(query)) {
        ps.setString(1, idLowongan);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String judulPekerjaan = rs.getString("Judul_Pekerjaan");
                String namaPerusahaan = rs.getString("Nama_Perusahaan");
                String lokasi = rs.getString("Lokasi");
                String gaji = rs.getString("Gaji");

                lowongan = new LowonganPekerjaan(idLowongan, judulPekerjaan, namaPerusahaan, lokasi, gaji);
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error fetching job details: " + e.getMessage());
    }

    return lowongan;
}
     public static LowonganPekerjaan getDetailPekerjaan1(String idLowongan) {
        String query = "SELECT lp.ID_Lowongan, lp.Judul_Pekerjaan, p.Nama_Perusahaan, lp.Lokasi, lp.Gaji, lp.Deskripsi_Pekerjaan " +
                       "FROM lowongan_pekerjaan lp " +
                       "JOIN perusahaan p ON lp.PERUSAHAAN_ID_Perusahaan = p.ID_Perusahaan " +
                       "WHERE lp.ID_Lowongan = ?";

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, idLowongan);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new LowonganPekerjaan(
                        rs.getString("ID_Lowongan"),
                        rs.getString("Judul_Pekerjaan"),
                        rs.getString("Nama_Perusahaan"),
                        rs.getString("Lokasi"),
                        rs.getString("Gaji"),
                        rs.getString("Deskripsi_Pekerjaan")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error loading job details: " + e.getMessage());
        }
        return null;
    }

    }

